//number
console.log(typeof 5);
console.log(typeof 5.5);

//문자열 String
console.log(typeof '문자열');

const username = 'Yoo';

console.log('저는',username,'입니다');
console.log('저는' + username+ '입니다');
console.log(`저는'+ ${username} + '입니다`);


console.log(``) //`(backtick, 백틱 기호),template literal 방식