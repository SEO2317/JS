//window 객체
console.log(window);

alert('hello'); //windowss는 생략가능


console.log(window.innerWidth); //현재 window 네비값

//BOM 객체

console.log(location);


console.log(location.href);

location.href = "https://www.naver.com";
href프로퍼티는 